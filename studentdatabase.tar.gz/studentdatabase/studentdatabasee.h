#ifndef STUDENTDATABASEE_H
#define STUDENTDATABASEE_H

#include <QMainWindow>
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlTableModel>
namespace Ui {
class studentdatabasee;
}

class studentdatabasee : public QMainWindow
{
    Q_OBJECT

public:
    explicit studentdatabasee(QWidget *parent = 0);
    ~studentdatabasee();
    QSqlTableModel *model;
    QSqlDatabase db;
    bool createDB(QString dbname);
    void setName(const QString n);
    void setRollNo(const QString p);
    void AddNewStudent(QString Name ,QString Roll_id);
    void VievDetails();
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::studentdatabasee *ui;
};

#endif // STUDENTDATABASEE_H
