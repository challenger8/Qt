#include "studentdatabasee.h"
#include "ui_studentdatabasee.h"
#include <QDir>
#include <QMessageBox>
#include <QtSql/QSqlRecord>
#include <QtSql/QSqlQuery>
#include <QtSql>
#include <QDebug>
studentdatabasee::studentdatabasee(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::studentdatabasee)
{
    ui->setupUi(this);
    QString path;
    path="/home/spirit/Desktop/qtt/studentdatabase";
    QDir file;
    QString filename=file.path()+QDir::separator()+"student.db";
    if(!createDB(filename))
    {
        QMessageBox::critical(this,tr("Database not found "),tr("Database not found. the application go to closed"),QMessageBox::Ok);
        qApp->exit();
    }
}

studentdatabasee::~studentdatabasee()
{
    delete ui;
}
bool studentdatabasee::createDB(QString dbname)
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName(dbname);
    db.open();
    if(db.open())
    {
        bool found = false;
        foreach (QString table,db.tables()) {
            if(table=="student"){
                found = true;
                break;
            }
        }
        if(!found){
        QSqlQuery  query(db);
        query.exec("create table student (name VARCHAR(32),Roll_id VARCHAR(16))");
        qDebug() << "removePerson error: "
                        << query.lastError();

        }
    model = new QSqlTableModel(this,db);
    model->setTable("student");
    model->setEditStrategy(QSqlTableModel::OnFieldChange);
    model->select();
}
    else
        return false;
    return true;
}
void studentdatabasee::AddNewStudent(QString Name, QString Roll_id)
{
QSqlRecord rec = model->record();
rec.setValue("name",Name);
rec.setValue("Roll_id",Roll_id);
model->insertRecord(-1,rec);
ui->textEdit->setText("");
ui->textEdit_2->setText("");
}
void studentdatabasee::on_pushButton_clicked()
{
QString Name= ui->textEdit->toPlainText();
QString Rollid=ui->textEdit_2->toPlainText();
AddNewStudent(Name,Rollid);
}

void studentdatabasee::on_pushButton_2_clicked()
{

    QModelIndex sample = ui->treeView->currentIndex();
    if(sample.row()>=0)
    {
        QMessageBox::StandardButton dlg;
        dlg = QMessageBox::question(this,tr("Remove Student"),
                                    QString(tr("Remove student 2")),QMessageBox::Yes | QMessageBox::No);
        if(dlg == QMessageBox::Yes)
        {
            model->removeRow(sample.row());
        }
    }
}


void studentdatabasee::on_pushButton_3_clicked()
{
QTreeView *view;
view=ui->treeView;
VievDetails();
}
void studentdatabasee::VievDetails(){
    QTreeView *view=ui->treeView;
    view->setModel(model );
}
